#!/bin/bash

source ./scripts/env.sh

verdi -nologo -ssf $ENV_DUMPFILE
